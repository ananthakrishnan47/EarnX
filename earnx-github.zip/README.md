# EarnX

A social + jobs web app built with TanStack Start, React 19, Tailwind CSS v4, and Lovable Cloud (Supabase).

## Features

- Email/password and Google OAuth authentication
- User profiles and social feed (posts, composer, profile cards)
- Job search powered by the Jooble API (online, offline, internships)
- Server functions via TanStack Start (`createServerFn`)
- Lovable Cloud backend (database, auth, storage)

## Tech Stack

- **Framework:** TanStack Start v1 + Vite 7
- **UI:** React 19, Tailwind CSS v4, shadcn/ui
- **Backend:** Lovable Cloud (Supabase)
- **Auth:** Supabase Auth + `@lovable.dev/cloud-auth-js` (Google OAuth)
- **Deploy target:** Cloudflare Workers (edge)

## Getting Started

### Prerequisites

- [Bun](https://bun.sh) (or Node.js 20+)

### Installation

```bash
bun install
```

### Environment Variables

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL="https://YOUR_PROJECT.supabase.co"
VITE_SUPABASE_PUBLISHABLE_KEY="your-anon-key"
VITE_SUPABASE_PROJECT_ID="your-project-id"
SUPABASE_URL="https://YOUR_PROJECT.supabase.co"
SUPABASE_PUBLISHABLE_KEY="your-anon-key"
```

Server-side secrets (set in your hosting platform, not committed):

- `JOOBLE_API_KEY` — Jooble jobs API key

### Development

```bash
bun dev
```

App runs at http://localhost:8080 (or the port Vite reports).

### Build

```bash
bun run build
```

## Project Structure

```
src/
├── routes/              # File-based routes (TanStack Router)
│   ├── __root.tsx       # Root layout
│   ├── index.tsx        # Home / feed
│   ├── auth.tsx         # Sign in / sign up (email + Google)
│   ├── profile.tsx
│   ├── jobs.online.tsx
│   ├── jobs.offline.tsx
│   └── jobs.internships.tsx
├── server/              # Server functions (createServerFn)
│   └── jooble.functions.ts
├── components/          # UI + feature components
├── integrations/
│   ├── supabase/        # Auto-generated Supabase client + types
│   └── lovable/         # Lovable Cloud auth helper
└── styles.css           # Tailwind v4 + design tokens
```

## Deployment

The project is configured for Cloudflare Workers (`wrangler.jsonc`). You can also deploy via the Lovable platform.

## License

MIT
