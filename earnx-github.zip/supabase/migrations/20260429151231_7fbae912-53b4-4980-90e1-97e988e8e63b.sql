
CREATE TYPE public.job_type AS ENUM ('online', 'offline', 'internship');

CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  company TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  location TEXT DEFAULT '',
  type public.job_type NOT NULL,
  apply_url TEXT,
  salary TEXT,
  posted_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX jobs_type_idx ON public.jobs(type);
CREATE INDEX jobs_created_at_idx ON public.jobs(created_at DESC);

ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Jobs viewable by authenticated users"
  ON public.jobs FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can post jobs"
  ON public.jobs FOR INSERT TO authenticated WITH CHECK (auth.uid() = posted_by);

CREATE POLICY "Users can update own jobs"
  ON public.jobs FOR UPDATE TO authenticated USING (auth.uid() = posted_by);

CREATE POLICY "Users can delete own jobs"
  ON public.jobs FOR DELETE TO authenticated USING (auth.uid() = posted_by);
