import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/Navbar";
import { PostCard, type FeedPost } from "@/components/PostCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export const Route = createFileRoute("/u/$userId")({
  component: UserProfilePage,
});

type ProfileFull = {
  id: string;
  full_name: string;
  headline: string | null;
  bio: string | null;
  location: string | null;
  avatar_url: string | null;
};

function UserProfilePage() {
  const { userId } = Route.useParams();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileFull | null>(null);
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data: prof } = await supabase
      .from("profiles")
      .select("id, full_name, headline, bio, location, avatar_url")
      .eq("id", userId)
      .maybeSingle();
    setProfile(prof);

    const { data: postRows } = await supabase
      .from("posts")
      .select("id, content, image_url, created_at, author_id, likes(user_id)")
      .eq("author_id", userId)
      .order("created_at", { ascending: false });

    const mapped: FeedPost[] = (postRows ?? []).map((p) => {
      const likes = (p as { likes: { user_id: string }[] }).likes ?? [];
      return {
        id: p.id,
        content: p.content,
        image_url: p.image_url,
        created_at: p.created_at,
        author_id: p.author_id,
        author_name: prof?.full_name ?? "Unknown",
        author_headline: prof?.headline ?? "",
        author_avatar: prof?.avatar_url ?? null,
        likes_count: likes.length,
        liked_by_me: !!user && likes.some((l) => l.user_id === user.id),
      };
    });
    setPosts(mapped);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, user?.id]);

  if (loading) return (<><Navbar /><div className="min-h-screen bg-background" /></>);

  if (!profile) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="mx-auto max-w-2xl px-4 py-20 text-center">
          <h1 className="text-xl font-semibold">User not found</h1>
          <Link to="/" className="mt-4 inline-block text-sm text-brand hover:underline">Back home</Link>
        </main>
      </div>
    );
  }

  const initials = profile.full_name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "U";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl space-y-4 px-4 py-6">
        <div
          className="overflow-hidden rounded-2xl border border-border/60 shadow-[var(--shadow-elegant)]"
          style={{ background: "var(--gradient-surface)" }}
        >
          <div className="h-28 bg-gradient-to-br from-brand/50 via-brand-glow/40 to-accent" />
          <div className="-mt-12 px-6 pb-6">
            <Avatar className="h-24 w-24 ring-4 ring-card">
              {profile.avatar_url && <AvatarImage src={profile.avatar_url} />}
              <AvatarFallback className="bg-accent text-accent-foreground text-2xl">{initials}</AvatarFallback>
            </Avatar>
            <h1 className="mt-4 text-2xl font-bold">{profile.full_name}</h1>
            {profile.headline && <p className="mt-0.5 text-sm text-muted-foreground">{profile.headline}</p>}
            {profile.location && (
              <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                {profile.location}
              </p>
            )}
            {profile.bio && (
              <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{profile.bio}</p>
            )}
          </div>
        </div>

        <h2 className="px-1 pt-2 text-sm font-semibold text-muted-foreground">Posts</h2>
        {posts.length === 0 ? (
          <div className="rounded-2xl border border-border/60 p-8 text-center text-sm text-muted-foreground">
            No posts yet.
          </div>
        ) : (
          posts.map((p) => (
            <PostCard
              key={p.id}
              post={p}
              currentUserId={user?.id ?? ""}
              onChanged={load}
            />
          ))
        )}
      </main>
    </div>
  );
}
