import { createFileRoute } from "@tanstack/react-router";
import { JobsPage } from "@/components/JobsPage";

export const Route = createFileRoute("/jobs/internships")({
  head: () => ({
    meta: [
      { title: "Internships — EarnX" },
      { name: "description", content: "Find and post internships on EarnX." },
      { property: "og:title", content: "Internships — EarnX" },
      { property: "og:description", content: "Kickstart your career with internships." },
    ],
  }),
  component: () => <JobsPage type="internship" />,
});
