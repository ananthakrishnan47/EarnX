import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Your profile — EarnX" },
      { name: "description", content: "Edit your professional profile." },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [fullName, setFullName] = useState("");
  const [headline, setHeadline] = useState("");
  const [bio, setBio] = useState("");
  const [location, setLocation] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/auth" });
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name, headline, bio, location, avatar_url")
        .eq("id", user.id)
        .maybeSingle();
      if (error) toast.error(error.message);
      if (data) {
        setFullName(data.full_name ?? "");
        setHeadline(data.headline ?? "");
        setBio(data.bio ?? "");
        setLocation(data.location ?? "");
        setAvatarUrl(data.avatar_url ?? "");
      }
      setLoading(false);
    })();
  }, [user]);

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("profiles").update({
      full_name: fullName,
      headline,
      bio,
      location,
      avatar_url: avatarUrl || null,
    }).eq("id", user.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Profile updated");
  };

  if (authLoading || loading || !user) {
    return <div className="min-h-screen bg-background" />;
  }

  const initials = fullName.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "U";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-2xl px-4 py-6">
        <div
          className="overflow-hidden rounded-2xl border border-border/60 shadow-[var(--shadow-elegant)]"
          style={{ background: "var(--gradient-surface)" }}
        >
          <div className="h-28 bg-gradient-to-br from-brand/50 via-brand-glow/40 to-accent" />
          <div className="-mt-12 px-6 pb-6">
            <Avatar className="h-24 w-24 ring-4 ring-card">
              {avatarUrl && <AvatarImage src={avatarUrl} />}
              <AvatarFallback className="bg-accent text-accent-foreground text-2xl">{initials}</AvatarFallback>
            </Avatar>

            <div className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fn">Full name</Label>
                <Input id="fn" value={fullName} onChange={(e) => setFullName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hl">Headline</Label>
                <Input id="hl" value={headline} onChange={(e) => setHeadline(e.target.value)} placeholder="Senior Engineer at Acme" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="loc">Location</Label>
                <Input id="loc" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Berlin, Germany" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="av">Avatar URL</Label>
                <Input id="av" value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} placeholder="https://…" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" rows={5} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Tell people what you're building." />
              </div>

              <div className="flex justify-end pt-2">
                <Button onClick={save} disabled={saving}>
                  {saving ? "Saving…" : "Save changes"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
