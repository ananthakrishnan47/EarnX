import { createFileRoute } from "@tanstack/react-router";
import { JobsPage } from "@/components/JobsPage";

export const Route = createFileRoute("/jobs/online")({
  head: () => ({
    meta: [
      { title: "Online Jobs — EarnX" },
      { name: "description", content: "Browse and post remote online jobs on EarnX." },
      { property: "og:title", content: "Online Jobs — EarnX" },
      { property: "og:description", content: "Remote roles you can do from anywhere." },
    ],
  }),
  component: () => <JobsPage type="online" />,
});
