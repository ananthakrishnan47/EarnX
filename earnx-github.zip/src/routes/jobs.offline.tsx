import { createFileRoute } from "@tanstack/react-router";
import { JobsPage } from "@/components/JobsPage";

export const Route = createFileRoute("/jobs/offline")({
  head: () => ({
    meta: [
      { title: "Part-time Jobs Near You — EarnX" },
      { name: "description", content: "Find part-time jobs for students near your location — cafés, retail, tutoring and event shifts." },
      { property: "og:title", content: "Part-time Jobs Near You — EarnX" },
      { property: "og:description", content: "Local part-time jobs for students, close to home or campus." },
    ],
  }),
  component: () => <JobsPage type="offline" />,
});
