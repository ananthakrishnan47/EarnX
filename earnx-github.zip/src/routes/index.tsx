import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Briefcase, GraduationCap, Globe, MapPin, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/Navbar";
import { PostComposer } from "@/components/PostComposer";
import { PostCard } from "@/components/PostCard";
import { ProfileCard, type ProfileSummary } from "@/components/ProfileCard";
import { useFeed } from "@/hooks/useFeed";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const { user, loading: authLoading } = useAuth();
  if (authLoading) return <div className="min-h-screen bg-background" />;
  return user ? <Feed /> : <Landing />;
}

function Landing() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen" style={{ background: "var(--gradient-hero)" }}>
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-20 text-center">
        <div className="mx-auto mb-8 inline-flex items-center gap-2 rounded-full border border-border/60 bg-surface/60 px-4 py-1.5 text-xs text-muted-foreground backdrop-blur">
          <Sparkles className="h-3.5 w-3.5 text-brand" />
          Built for students. Earn while you learn.
        </div>
        <h1 className="mx-auto max-w-3xl bg-gradient-to-br from-foreground to-muted-foreground bg-clip-text text-5xl font-bold leading-tight tracking-tight text-transparent sm:text-6xl">
          Part-time jobs for students, right around the corner
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">
          Find flexible shifts near your campus or home, pick up remote side gigs that fit your timetable, and land internships that actually pay.
        </p>
        <div className="mt-10 flex items-center justify-center gap-3">
          <Button size="lg" onClick={() => navigate({ to: "/jobs/offline" })} className="shadow-[var(--shadow-glow)]">
            Find jobs near me
          </Button>
          <Button size="lg" variant="ghost" onClick={() => navigate({ to: "/auth" })}>
            Sign in
          </Button>
        </div>

        <div className="mt-20 grid gap-6 sm:grid-cols-3">
          {[
            { icon: MapPin, title: "Part-time Near You", desc: "Cafés, retail, tutoring & event gigs close to your location.", to: "/jobs/offline" as const },
            { icon: Globe, title: "Remote Side Gigs", desc: "Online work you can do between classes, from anywhere.", to: "/jobs/online" as const },
            { icon: GraduationCap, title: "Student Internships", desc: "Get real experience and build your CV while you study.", to: "/jobs/internships" as const },
          ].map(({ icon: Icon, title, desc, to }) => (
            <Link
              key={title}
              to={to}
              className="rounded-2xl border border-border/60 p-6 text-left shadow-[var(--shadow-elegant)] transition-transform hover:-translate-y-0.5 hover:border-brand/50"
              style={{ background: "var(--gradient-surface)" }}
            >
              <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-brand/15 text-brand">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-semibold">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}

function Feed() {
  const { user } = useAuth();
  const userId = user!.id;
  const [profile, setProfile] = useState<ProfileSummary | null>(null);
  const [postCount, setPostCount] = useState(0);
  const { posts, loading, reload } = useFeed(userId);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, headline, avatar_url, location")
        .eq("id", userId)
        .maybeSingle();
      if (data) setProfile(data);
      const { count } = await supabase
        .from("posts")
        .select("id", { count: "exact", head: true })
        .eq("author_id", userId);
      setPostCount(count ?? 0);
    })();
  }, [userId, posts.length]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto grid max-w-5xl gap-6 px-4 py-6 lg:grid-cols-[260px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-20">
            {profile && <ProfileCard profile={profile} postCount={postCount} />}
          </div>
        </aside>

        <section className="space-y-4">
          {profile && (
            <PostComposer
              userId={userId}
              authorName={profile.full_name}
              avatarUrl={profile.avatar_url}
              onCreated={reload}
            />
          )}

          {loading && (
            <div className="rounded-2xl border border-border/60 p-8 text-center text-sm text-muted-foreground">
              Loading feed…
            </div>
          )}

          {!loading && posts.length === 0 && (
            <div
              className="rounded-2xl border border-border/60 p-10 text-center"
              style={{ background: "var(--gradient-surface)" }}
            >
              <Sparkles className="mx-auto mb-3 h-8 w-8 text-brand" />
              <h3 className="font-semibold">Your feed is quiet</h3>
              <p className="mt-1 text-sm text-muted-foreground">Be the first to share something today.</p>
            </div>
          )}

          {posts.map((p) => (
            <PostCard key={p.id} post={p} currentUserId={userId} onChanged={reload} />
          ))}
        </section>
      </main>
    </div>
  );
}
