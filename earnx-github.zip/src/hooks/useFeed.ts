import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { FeedPost } from "@/components/PostCard";

export function useFeed(currentUserId: string | undefined) {
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!currentUserId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("posts")
      .select("id, content, image_url, created_at, author_id, profiles!posts_author_id_fkey(full_name, headline, avatar_url), likes(user_id)")
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) {
      console.error(error);
      setLoading(false);
      return;
    }

    const mapped: FeedPost[] = (data ?? []).map((p) => {
      const profile = (p as { profiles: { full_name: string; headline: string | null; avatar_url: string | null } | null }).profiles;
      const likes = (p as { likes: { user_id: string }[] }).likes ?? [];
      return {
        id: p.id,
        content: p.content,
        image_url: p.image_url,
        created_at: p.created_at,
        author_id: p.author_id,
        author_name: profile?.full_name || "Unknown",
        author_headline: profile?.headline || "",
        author_avatar: profile?.avatar_url ?? null,
        likes_count: likes.length,
        liked_by_me: likes.some((l) => l.user_id === currentUserId),
      };
    });
    setPosts(mapped);
    setLoading(false);
  }, [currentUserId]);

  useEffect(() => {
    load();
  }, [load]);

  return { posts, loading, reload: load };
}
