import { Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export type ProfileSummary = {
  id: string;
  full_name: string;
  headline: string | null;
  avatar_url: string | null;
  location: string | null;
};

export function ProfileCard({ profile, postCount }: { profile: ProfileSummary; postCount: number }) {
  const initials = profile.full_name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "U";

  return (
    <div
      className="overflow-hidden rounded-2xl border border-border/60 shadow-[var(--shadow-elegant)]"
      style={{ background: "var(--gradient-surface)" }}
    >
      <div className="h-16 bg-gradient-to-br from-brand/40 via-brand-glow/30 to-accent" />
      <div className="-mt-8 flex flex-col items-center px-4 pb-4 text-center">
        <Avatar className="h-16 w-16 ring-4 ring-card">
          {profile.avatar_url && <AvatarImage src={profile.avatar_url} />}
          <AvatarFallback className="bg-accent text-accent-foreground text-lg">{initials}</AvatarFallback>
        </Avatar>
        <Link to="/profile" className="mt-2 text-sm font-semibold hover:underline">
          {profile.full_name || "You"}
        </Link>
        {profile.headline && (
          <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{profile.headline}</p>
        )}
        {profile.location && (
          <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            {profile.location}
          </p>
        )}
        <div className="mt-4 w-full rounded-lg border border-border/60 bg-background/40 p-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Posts</span>
            <span className="font-semibold text-brand">{postCount}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
