import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Briefcase, Globe, GraduationCap, Home, LogOut, MapPin, User as UserIcon } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });

  const handleSignOut = async () => {
    await signOut();
    navigate({ to: "/auth" });
  };

  const navItem = (to: string, label: string, Icon: typeof Home) => {
    const active = path === to || (to !== "/" && path.startsWith(to));
    return (
      <Link
        to={to}
        className={`flex flex-col items-center gap-0.5 px-4 py-2 text-xs font-medium transition-colors ${
          active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Icon className="h-5 w-5" />
        <span className="hidden sm:inline">{label}</span>
        {active && <span className="absolute bottom-0 h-0.5 w-10 rounded-t bg-brand" />}
      </Link>
    );
  };

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-5xl items-center gap-4 px-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-glow">
            <Briefcase className="h-4 w-4 text-brand-foreground" />
          </div>
          <span className="text-lg font-bold tracking-tight">EarnX</span>
        </Link>

        <div className="flex-1" />

        {user ? (
          <nav className="relative flex items-center gap-1">
            {navItem("/", "Home", Home)}
            {navItem("/jobs/online", "Online", Globe)}
            {navItem("/jobs/offline", "Offline", MapPin)}
            {navItem("/jobs/internships", "Interns", GraduationCap)}
            {navItem("/profile", "Profile", UserIcon)}
            <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-muted-foreground">
              <LogOut className="h-4 w-4" />
            </Button>
          </nav>
        ) : (
          <Button asChild variant="default" size="sm">
            <Link to="/auth">Sign in</Link>
          </Button>
        )}
      </div>
    </header>
  );
}
