import { useState } from "react";
import { Heart, MessageCircle, Share2, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export type FeedPost = {
  id: string;
  content: string;
  image_url: string | null;
  created_at: string;
  author_id: string;
  author_name: string;
  author_headline: string;
  author_avatar: string | null;
  likes_count: number;
  liked_by_me: boolean;
};

type Props = {
  post: FeedPost;
  currentUserId: string;
  onChanged: () => void;
};

export function PostCard({ post, currentUserId, onChanged }: Props) {
  const [liked, setLiked] = useState(post.liked_by_me);
  const [count, setCount] = useState(post.likes_count);
  const [busy, setBusy] = useState(false);

  const initials = post.author_name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "U";
  const isMine = post.author_id === currentUserId;

  const toggleLike = async () => {
    if (busy) return;
    setBusy(true);
    if (liked) {
      setLiked(false);
      setCount((c) => c - 1);
      const { error } = await supabase.from("likes").delete().eq("post_id", post.id).eq("user_id", currentUserId);
      if (error) {
        setLiked(true);
        setCount((c) => c + 1);
        toast.error("Could not unlike");
      }
    } else {
      setLiked(true);
      setCount((c) => c + 1);
      const { error } = await supabase.from("likes").insert({ post_id: post.id, user_id: currentUserId });
      if (error) {
        setLiked(false);
        setCount((c) => c - 1);
        toast.error("Could not like");
      }
    }
    setBusy(false);
  };

  const remove = async () => {
    if (!confirm("Delete this post?")) return;
    const { error } = await supabase.from("posts").delete().eq("id", post.id);
    if (error) return toast.error(error.message);
    toast.success("Post deleted");
    onChanged();
  };

  return (
    <article
      className="overflow-hidden rounded-2xl border border-border/60 shadow-[var(--shadow-elegant)] transition-all hover:border-border"
      style={{ background: "var(--gradient-surface)" }}
    >
      <header className="flex items-start gap-3 p-4">
        <Avatar className="h-11 w-11 ring-2 ring-border">
          {post.author_avatar && <AvatarImage src={post.author_avatar} />}
          <AvatarFallback className="bg-accent text-accent-foreground">{initials}</AvatarFallback>
        </Avatar>
        <div className="min-w-0 flex-1">
          <Link
            to="/u/$userId"
            params={{ userId: post.author_id }}
            className="block truncate text-sm font-semibold hover:underline"
          >
            {post.author_name}
          </Link>
          {post.author_headline && (
            <p className="truncate text-xs text-muted-foreground">{post.author_headline}</p>
          )}
          <p className="text-xs text-muted-foreground">
            {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
          </p>
        </div>
        {isMine && (
          <Button variant="ghost" size="icon" onClick={remove} className="text-muted-foreground hover:text-destructive">
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </header>

      <div className="px-4 pb-3">
        <p className="whitespace-pre-wrap text-sm leading-relaxed">{post.content}</p>
      </div>

      {post.image_url && (
        <div className="border-y border-border/60 bg-background/30">
          <img src={post.image_url} alt="" className="max-h-[480px] w-full object-cover" loading="lazy" />
        </div>
      )}

      <footer className="flex items-center gap-1 border-t border-border/60 px-2 py-1.5">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleLike}
          className={`flex-1 ${liked ? "text-brand" : "text-muted-foreground"}`}
        >
          <Heart className={`mr-2 h-4 w-4 ${liked ? "fill-current" : ""}`} />
          <span className="text-xs">{count > 0 ? count : ""} Like</span>
        </Button>
        <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground" disabled>
          <MessageCircle className="mr-2 h-4 w-4" />
          <span className="text-xs">Comment</span>
        </Button>
        <Button variant="ghost" size="sm" className="flex-1 text-muted-foreground" disabled>
          <Share2 className="mr-2 h-4 w-4" />
          <span className="text-xs">Share</span>
        </Button>
      </footer>
    </article>
  );
}
