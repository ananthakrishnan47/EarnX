import { useState } from "react";
import { Image as ImageIcon, Send } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

type Props = {
  authorName: string;
  avatarUrl: string | null;
  userId: string;
  onCreated: () => void;
};

export function PostComposer({ authorName, avatarUrl, userId, onCreated }: Props) {
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [showImage, setShowImage] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const initials = authorName.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "U";

  const submit = async () => {
    if (!content.trim()) return;
    setSubmitting(true);
    const { error } = await supabase.from("posts").insert({
      author_id: userId,
      content: content.trim(),
      image_url: imageUrl.trim() || null,
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    setContent("");
    setImageUrl("");
    setShowImage(false);
    onCreated();
    toast.success("Post shared");
  };

  return (
    <div
      className="rounded-2xl border border-border/60 p-4 shadow-[var(--shadow-elegant)]"
      style={{ background: "var(--gradient-surface)" }}
    >
      <div className="flex gap-3">
        <Avatar className="h-10 w-10 ring-2 ring-border">
          {avatarUrl && <AvatarImage src={avatarUrl} />}
          <AvatarFallback className="bg-accent text-accent-foreground">{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-3">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Share an update, idea, or win…"
            rows={3}
            className="resize-none border-border/60 bg-background/50"
          />
          {showImage && (
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="Paste image URL"
              className="w-full rounded-md border border-border/60 bg-background/50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          )}
          <div className="flex items-center justify-between">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setShowImage((s) => !s)}
              className="text-muted-foreground"
            >
              <ImageIcon className="mr-2 h-4 w-4" />
              {showImage ? "Hide image" : "Add image"}
            </Button>
            <Button onClick={submit} disabled={submitting || !content.trim()} size="sm">
              <Send className="mr-2 h-4 w-4" />
              Post
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
