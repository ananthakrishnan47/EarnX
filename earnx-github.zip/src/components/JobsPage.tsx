import { useEffect, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Briefcase, MapPin, ExternalLink, Plus, Loader2, Trash2, Search, Globe2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { searchJoobleJobs, type JoobleJob } from "@/server/jooble.functions";

export type JobType = "online" | "offline" | "internship";

type Job = {
  id: string;
  title: string;
  company: string;
  description: string;
  location: string | null;
  type: JobType;
  apply_url: string | null;
  salary: string | null;
  posted_by: string;
  created_at: string;
};

const COPY: Record<JobType, { title: string; subtitle: string; cta: string; defaultKeywords: string }> = {
  online: {
    title: "Remote Side Gigs",
    subtitle: "Online part-time work you can do between classes, from anywhere.",
    cta: "Post a remote gig",
    defaultKeywords: "remote part time student",
  },
  offline: {
    title: "Part-time Jobs Near You",
    subtitle: "Cafés, retail, tutoring and event shifts close to your location.",
    cta: "Post a local job",
    defaultKeywords: "part time student",
  },
  internship: {
    title: "Student Internships",
    subtitle: "Paid internships that fit around your studies and grow your CV.",
    cta: "Post an internship",
    defaultKeywords: "internship student",
  },
};

export function JobsPage({ type }: { type: JobType }) {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [locationQuery, setLocationQuery] = useState("");
  const [keywords, setKeywords] = useState(COPY[type].defaultKeywords);
  const [joobleJobs, setJoobleJobs] = useState<JoobleJob[]>([]);
  const [joobleLoading, setJoobleLoading] = useState(false);
  const [joobleError, setJoobleError] = useState<string | null>(null);
  const searchJooble = useServerFn(searchJoobleJobs);
  const copy = COPY[type];

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("jobs")
      .select("*")
      .eq("type", type)
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    else setJobs((data ?? []) as Job[]);
    setLoading(false);
  };

  const runJoobleSearch = async () => {
    setJoobleLoading(true);
    setJoobleError(null);
    const loc = type === "online" ? "" : locationQuery.trim();
    const res = await searchJooble({
      data: { keywords: keywords.trim() || copy.defaultKeywords, location: loc, page: 1 },
    });
    if (res.error) setJoobleError(res.error);
    setJoobleJobs(res.jobs);
    setJoobleLoading(false);
  };

  useEffect(() => {
    load();
    setKeywords(COPY[type].defaultKeywords);
    setJoobleJobs([]);
    setJoobleError(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("jobs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Job removed");
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="mb-8 flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{copy.title}</h1>
            <p className="mt-1 text-muted-foreground">{copy.subtitle}</p>
          </div>
          {user ? (
            <PostJobDialog
              type={type}
              userId={user.id}
              open={open}
              setOpen={setOpen}
              onCreated={load}
              ctaLabel={copy.cta}
            />
          ) : (
            <Button asChild>
              <Link to="/auth">Sign in to post</Link>
            </Button>
          )}
        </div>

        {/* Jooble live search */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            runJoobleSearch();
          }}
          className="mb-6 rounded-2xl border border-border/60 p-4"
          style={{ background: "var(--gradient-surface)" }}
        >
          <div className="mb-3 flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
            <Globe2 className="h-3.5 w-3.5 text-brand" />
            Search live listings from across the web
          </div>
          <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
            <div className="flex items-center gap-2 rounded-md border border-border bg-background px-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="What job? e.g. barista, tutor, designer"
                className="border-0 px-0 focus-visible:ring-0"
              />
            </div>
            {type !== "online" && (
              <div className="flex items-center gap-2 rounded-md border border-border bg-background px-2">
                <MapPin className="h-4 w-4 text-brand" />
                <Input
                  value={locationQuery}
                  onChange={(e) => setLocationQuery(e.target.value)}
                  placeholder="Where? city or postcode"
                  className="border-0 px-0 focus-visible:ring-0"
                />
              </div>
            )}
            <Button type="submit" disabled={joobleLoading}>
              {joobleLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Search"}
            </Button>
          </div>
          {joobleError && (
            <p className="mt-2 text-xs text-destructive">{joobleError}</p>
          )}
        </form>

        {joobleJobs.length > 0 && (
          <section className="mb-8">
            <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
              {joobleJobs.length} live results
            </h2>
            <div className="space-y-3">
              {joobleJobs.map((j) => (
                <article
                  key={j.id}
                  className="rounded-2xl border border-border/60 p-5 transition-colors hover:border-border"
                  style={{ background: "var(--gradient-surface)" }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <h3 className="text-lg font-semibold">{j.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {j.company || j.source}
                        {j.location && (
                          <>
                            {" · "}
                            <span className="inline-flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {j.location}
                            </span>
                          </>
                        )}
                        {j.salary && <> · {j.salary}</>}
                      </p>
                    </div>
                    {j.link && (
                      <Button asChild size="sm">
                        <a href={j.link} target="_blank" rel="noreferrer">
                          Apply <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    )}
                  </div>
                  {j.snippet && (
                    <p className="mt-3 line-clamp-3 text-sm text-foreground/90">{j.snippet}</p>
                  )}
                </article>
              ))}
            </div>
          </section>
        )}

        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Posted by the community</h2>
        {(() => {
          const filtered = type === "offline" && locationQuery.trim()
            ? jobs.filter((j) => (j.location ?? "").toLowerCase().includes(locationQuery.trim().toLowerCase()))
            : jobs;
          if (loading) return (
            <div className="flex items-center justify-center py-16 text-muted-foreground">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading jobs…
            </div>
          );
          if (filtered.length === 0) return (
            <div
              className="rounded-2xl border border-border/60 p-10 text-center"
              style={{ background: "var(--gradient-surface)" }}
            >
              <Briefcase className="mx-auto mb-3 h-8 w-8 text-brand" />
              <h3 className="font-semibold">{jobs.length === 0 ? "No community listings yet" : "No matches near that area"}</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {jobs.length === 0
                  ? `Search above for live results, or be the first to post a ${copy.title.toLowerCase()}.`
                  : "Try a broader area or clear the filter."}
              </p>
            </div>
          );
          return (
          <div className="space-y-3">
            {filtered.map((j) => (
              <article
                key={j.id}
                className="rounded-2xl border border-border/60 p-5 transition-colors hover:border-border"
                style={{ background: "var(--gradient-surface)" }}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <h2 className="text-lg font-semibold">{j.title}</h2>
                    <p className="text-sm text-muted-foreground">
                      {j.company}
                      {j.location && (
                        <>
                          {" · "}
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {j.location}
                          </span>
                        </>
                      )}
                      {j.salary && <> · {j.salary}</>}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {j.apply_url && (
                      <Button asChild size="sm">
                        <a href={j.apply_url} target="_blank" rel="noreferrer">
                          Apply <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    )}
                    {user?.id === j.posted_by && (
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleDelete(j.id)}
                        aria-label="Delete job"
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    )}
                  </div>
                </div>
                {j.description && (
                  <p className="mt-3 whitespace-pre-wrap text-sm text-foreground/90">
                    {j.description}
                  </p>
                )}
              </article>
            ))}
          </div>
          );
        })()}
      </main>
    </div>
  );
}

function PostJobDialog({
  type,
  userId,
  open,
  setOpen,
  onCreated,
  ctaLabel,
}: {
  type: JobType;
  userId: string;
  open: boolean;
  setOpen: (v: boolean) => void;
  onCreated: () => void;
  ctaLabel: string;
}) {
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    title: "",
    company: "",
    location: "",
    salary: "",
    apply_url: "",
    description: "",
  });

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.company) return toast.error("Title and company are required");
    setSubmitting(true);
    const { error } = await supabase.from("jobs").insert({
      title: form.title,
      company: form.company,
      location: form.location,
      salary: form.salary || null,
      apply_url: form.apply_url || null,
      description: form.description,
      type,
      posted_by: userId,
    });
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Job posted!");
    setForm({ title: "", company: "", location: "", salary: "", apply_url: "", description: "" });
    setOpen(false);
    onCreated();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-1 h-4 w-4" /> {ctaLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{ctaLabel}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label htmlFor="title">Title</Label>
            <Input id="title" value={form.title} onChange={update("title")} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="company">Company</Label>
              <Input id="company" value={form.company} onChange={update("company")} required />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={form.location}
                onChange={update("location")}
                placeholder={type === "online" ? "Remote" : "City, Country"}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="salary">Salary (optional)</Label>
              <Input id="salary" value={form.salary} onChange={update("salary")} placeholder="$60k–$80k" />
            </div>
            <div>
              <Label htmlFor="apply_url">Apply URL</Label>
              <Input
                id="apply_url"
                type="url"
                value={form.apply_url}
                onChange={update("apply_url")}
                placeholder="https://..."
              />
            </div>
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={form.description}
              onChange={update("description")}
              rows={5}
              placeholder="What will they be doing? Requirements? Perks?"
            />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={submitting}>
              {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Post job
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
