import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  keywords: z.string().min(1).max(200),
  location: z.string().max(200).optional().default(""),
  page: z.number().int().min(1).max(20).optional().default(1),
});

export type JoobleJob = {
  id: string;
  title: string;
  company: string;
  location: string;
  snippet: string;
  salary: string;
  source: string;
  type: string;
  link: string;
  updated: string;
};

export const searchJoobleJobs = createServerFn({ method: "POST" })
  .inputValidator((input) => Input.parse(input))
  .handler(async ({ data }): Promise<{ jobs: JoobleJob[]; totalCount: number; error: string | null }> => {
    const key = process.env.JOOBLE_API_KEY;
    if (!key) {
      return { jobs: [], totalCount: 0, error: "JOOBLE_API_KEY is not configured" };
    }
    try {
      const res = await fetch(`https://jooble.org/api/${key}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          keywords: data.keywords,
          location: data.location ?? "",
          page: String(data.page ?? 1),
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        return { jobs: [], totalCount: 0, error: `Jooble error ${res.status}: ${text.slice(0, 200)}` };
      }
      const json = (await res.json()) as { jobs?: any[]; totalCount?: number };
      const jobs: JoobleJob[] = (json.jobs ?? []).map((j, i) => ({
        id: String(j.id ?? `${i}-${j.link ?? ""}`),
        title: String(j.title ?? ""),
        company: String(j.company ?? ""),
        location: String(j.location ?? ""),
        snippet: String(j.snippet ?? "").replace(/<[^>]+>/g, ""),
        salary: String(j.salary ?? ""),
        source: String(j.source ?? ""),
        type: String(j.type ?? ""),
        link: String(j.link ?? ""),
        updated: String(j.updated ?? ""),
      }));
      return { jobs, totalCount: json.totalCount ?? jobs.length, error: null };
    } catch (e) {
      return { jobs: [], totalCount: 0, error: e instanceof Error ? e.message : "Unknown error" };
    }
  });
